# VR Painting Project
This project took me about 6 media lessons to create.

It's a web-VR website that allows you to use your oculus quest 2 controller as paint brush.

#### Possible Future Additions:
- Add settings, like changing the main controller to the left controller.
- Add support for multiple types of headsets.
- Figure out a way to prevent lag after a lot of brushwork.
- Make colorpicker ui follow secondary controller.
- Allow custom colors to be used. 
- Add multiple types of brushes.